package com.mindgate.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindgate.main.pojo.ProjectDetails;
import com.mindgate.main.repository.ProjectDetailsRepositoryInterface;

@Service
public class ProjectDetailsService implements ProjectDetailsServiceInterface{

	@Autowired
	private ProjectDetailsRepositoryInterface projectDetailsRepository;

	
	@Override
	public boolean addNewProjectDetails(ProjectDetails projectDetails) {
		return projectDetailsRepository.addNewProject(projectDetails);
	}

	@Override
	public boolean updateProjectDeatilsByProjectId(ProjectDetails projectDetails) {
		return projectDetailsRepository.updateProjectByProjectId(projectDetails);
	}

	
	@Override
	public boolean deleteProjectDetailsByProjectId(int projectId) {
		return projectDetailsRepository.deleteProjectByProjectId(projectId);
	}

	
	@Override
	public ProjectDetails getProjectDetailsByProjectId(int projectId) {
		return projectDetailsRepository.getProjectByProjectId(projectId);
	}

	
	@Override
	public List<ProjectDetails> getAllProjectsDetails() {
		return projectDetailsRepository.getAllProjectsDetails();
	}

	
	@Override
	public List<ProjectDetails> getAllProjectsDetailsByprojectId(int projectId) {
		return projectDetailsRepository.getAllProjectsDetailsByprojectId(projectId);
	}
	
}
