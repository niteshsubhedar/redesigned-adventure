package com.mindgate.main.service;

import com.mindgate.main.pojo.EmailDetails;

public interface EmailServiceInterface {
	public boolean sendSimpleMail(EmailDetails details);
}
