package com.mindgate.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindgate.main.pojo.CandidateDetails;
import com.mindgate.main.repository.CandidateDetailsRepositoryInterface;

@Service
public class CandidateDetailsService implements CandidateDetailsServiceInterface {

	@Autowired
	private CandidateDetailsRepositoryInterface candidateDetailsRepository;

	@Override
	public boolean addNewCandidateDetails(CandidateDetails candidateDetails) {
		return candidateDetailsRepository.addNewCandidateDetails(candidateDetails);
	}

	@Override
	public boolean updateCandidateDetailsByCandidateId(CandidateDetails candidateDetails) {
		return candidateDetailsRepository.updateCandidateDetailsDetailsByCandidateId(candidateDetails);
	}

	@Override
	public boolean deleteCandidateDetailsByCandidateId(int candidateId) {
		return candidateDetailsRepository.deleteCandidateDetailsDetailsByCandidateId(candidateId);
	}

	@Override
	public CandidateDetails getCandidateDetailsByCandidateId(int candidateId) {
		return candidateDetailsRepository.getCandidateDetailsByCandidateId(candidateId);
	}

	@Override
	public List<CandidateDetails> getAllCandidateDetails() {
		return candidateDetailsRepository.getAllCandidateDetails();
	}

	@Override
	public boolean updateCandidateDetailsByStatus(CandidateDetails candidateDetails) {
		return candidateDetailsRepository.updateCandidateDetailsByStatus(candidateDetails);
	}

	@Override
	public List<CandidateDetails> getAllInprocessCandidateDetails() {
		return candidateDetailsRepository.getAllInprocessCandidateDetails();
	}

	@Override
	public boolean updateCandidateDetailsDetailsByCandidateId(String interviewStatus, int candidateId) {
		return candidateDetailsRepository.updateCandidateDetailsDetailsByCandidateId(interviewStatus, candidateId);
	}

	@Override
	public List<CandidateDetails> getAllSelectedCandidateDetails() {
		return candidateDetailsRepository.getAllSelectedCandidateDetails();
	}

	@Override
	public List<CandidateDetails> getAllPendingCandidateDetails() {
		return candidateDetailsRepository.getAllPendingCandidateDetails();
	}

	@Override
	public List<CandidateDetails> getAllNewCandidateDetails() {
		return candidateDetailsRepository.getAllNewCandidateDetails();
	}

	@Override
	public List<CandidateDetails> getAllRejectedCandidateDetails() {
		return candidateDetailsRepository.getAllRejectedCandidateDetails();
	}
	
}
